package com.example.coronacases;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CoronaAdapter extends BaseAdapter {
    ArrayList<Corona> CoronaData;
    LayoutInflater layoutInflater;

    public CoronaAdapter(Context context, ArrayList<Corona> CoronaData) {
        this.CoronaData = CoronaData;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return CoronaData.size();
    }

    @Override
    public Object getItem(int i) {
        return CoronaData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if(view==null){
            view = layoutInflater.inflate(R.layout.list_row,null);
            holder = new ViewHolder();
            holder.CountryName=view.findViewById(R.id.tvCountry);
            holder.CountryCases=view.findViewById(R.id.tvTCases);
            view.setTag(holder);
        }
        else
            holder = (ViewHolder) view.getTag();
        holder.CountryName.setText(CoronaData.get(i).getCountry());
        holder.CountryCases.setText(String.format("%d",CoronaData.get(i).getAllCases()));
        return view;
    }
    static class ViewHolder{
        TextView CountryName;
        TextView CountryCases;

    }
}
